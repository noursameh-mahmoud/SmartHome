/*
 * LM35_config.h
 *
 * Created: 7/6/2024 11:49:06 PM
 *  Author: waadr
 */ 


#ifndef LM35_CONFIG_H_
#define LM35_CONFIG_H_

#define LM35_CHANNEL_NUM               ADC_CHANNEL0



#endif /* LM35_CONFIG_H_ */