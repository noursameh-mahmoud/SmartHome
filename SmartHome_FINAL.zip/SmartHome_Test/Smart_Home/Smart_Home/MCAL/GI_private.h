/*
 * GI_private.h
 *
 * Created: 3/11/2024 1:25:06 PM
 *  Author: waadr
 */ 


#ifndef GI_PRIVATE_H_
#define GI_PRIVATE_H_

#define SREG       (*(volatile u8*)0x5F)
#define  I           7



#endif /* GI_PRIVATE_H_ */