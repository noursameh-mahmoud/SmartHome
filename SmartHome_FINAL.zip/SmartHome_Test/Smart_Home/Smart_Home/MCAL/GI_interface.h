/*
 * GI_interface.h
 *
 * Created: 3/11/2024 1:24:29 PM
 *  Author: waadr
 */ 


#ifndef GI_INTERFACE_H_
#define GI_INTERFACE_H_

void GI_enable(void);
void GI_disable(void);



#endif /* GI_INTERFACE_H_ */